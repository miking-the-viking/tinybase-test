const o=(o,t)=>o<t?-1:1;export{o as defaultSorter};
