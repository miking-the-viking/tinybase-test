"use strict";exports.defaultSorter=(t,e)=>t<e?-1:1;
